import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import jsPDF from "jspdf";

const winterLogo = "data:image/png;base64,...invierno...";
const springLogo = "data:image/png;base64,...primavera...";
const summerLogo = "data:image/png;base64,...verano...";
const autumnLogo = "data:image/png;base64,...otono...";

const getSeasonLogo = () => {
  const month = new Date().getMonth();
  if ([11, 0, 1].includes(month)) return winterLogo;
  if ([2, 3, 4].includes(month)) return springLogo;
  if ([5, 6, 7].includes(month)) return summerLogo;
  return autumnLogo;
};

const logoBase64 = getSeasonLogo();

export default function BioGestorApp() {
  const [wasteType, setWasteType] = useState("");
  const [reuseIdeas, setReuseIdeas] = useState("");
  const [suggestion, setSuggestion] = useState("");
  const [confirmation, setConfirmation] = useState(false);

  const reuseDatabase = {
    "Residuos orgánicos": [
      "Compostaje para agricultura",
      "Alimento para animales (si aplica)",
      "Producción de biogás",
      "Harinas vegetales deshidratadas"
    ],
    "Aceites usados": [
      "Producción de biodiésel",
      "Jabones ecológicos",
      "Reciclaje industrial"
    ],
    "Envases plásticos": [
      "Reciclaje para nuevos envases",
      "Ladrillos ecológicos",
      "Material de construcción reciclado"
    ],
    "Cartón y papel": [
      "Reciclaje para nuevos papeles",
      "Aislantes ecológicos",
      "Artesanías recicladas"
    ],
    "Desechos de origen animal": [
      "Harinas proteicas para animales",
      "Producción de colágeno",
      "Transformación en biocombustibles"
    ],
    "Aguas residuales": [
      "Riego industrial (tras tratamiento)",
      "Limpieza de pisos o maquinaria (si permitido)",
      "Recuperación de grasas"
    ]
  };

  const regulationsDatabase = {
    "Residuos orgánicos": [
      "Reglamento (CE) N° 1069/2009: normas sanitarias aplicables a subproductos animales.",
      "Ley de residuos alimentarios nacional/local.",
      "Directiva UE 2008/98/CE sobre residuos."
    ],
    "Aceites usados": [
      "Directiva 2008/98/CE: jerarquía de residuos.",
      "Normativas locales sobre residuos peligrosos y vertido de aceites.",
      "Reglamento REACH si aplica a procesos químicos."
    ],
    "Envases plásticos": [
      "Directiva UE 94/62/CE sobre envases y residuos de envases.",
      "Normativas locales sobre reciclaje de envases."
    ],
    "Cartón y papel": [
      "Normas ISO 14001 (gestión ambiental).",
      "Regulación sobre separación en origen y reciclaje."
    ],
    "Desechos de origen animal": [
      "Reglamento (CE) N° 1069/2009.",
      "Normas de transporte y almacenamiento de residuos cárnicos.",
      "HACCP (Análisis de Peligros y Puntos Críticos de Control)."
    ],
    "Aguas residuales": [
      "Normativa local sobre vertido de aguas industriales.",
      "Normas de tratamiento previo antes de descarga al alcantarillado."
    ]
  };

  const handleSearch = () => {
    const ideas = reuseDatabase[wasteType];
    const norms = regulationsDatabase[wasteType];
    if (!ideas || !norms) {
      setReuseIdeas("❌ Tipo de residuo no reconocido. Revisa la ortografía o selecciona uno de la lista.");
      return;
    }
    setReuseIdeas(
      "▶ Aprovechamiento:
" +
      ideas.join("
") +
      "

▶ Normativas aplicables:
" +
      norms.join("
")
    );
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    const imgProps = doc.getImageProperties(logoBase64);
    const imgHeight = (imgProps.height * 30) / imgProps.width;
    doc.addImage(logoBase64, 'PNG', 150, 10, 30, imgHeight);
    doc.setFontSize(14);
    doc.text("BioGestor: Gestión de Residuos en Empresas de Procesamiento de Alimentos", 10, 20);
    doc.setFontSize(10);
    doc.text("La herramienta inteligente para residuos industriales alimentarios", 10, 28);
    doc.setFontSize(12);
    const lines = reuseIdeas.split("
");
    lines.forEach((line, i) => {
      doc.text(line, 10, 30 + i * 8);
    });
    doc.save(`residuos_${wasteType.replace(/\s/g, "_")}.pdf`);
  };

  const handleDownloadAllPDF = () => {
    alert("Funcionalidad en desarrollo. Pronto podrás descargar toda la guía completa.");
  };

  return null;
}
