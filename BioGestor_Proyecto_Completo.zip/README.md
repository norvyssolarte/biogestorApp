# BioGestor

**BioGestor** es una aplicación web que ayuda a empresas del sector alimentario a gestionar sus residuos de manera sostenible y legalmente conforme.

## Funciones destacadas

- ♻️ Recomendaciones de aprovechamiento según el tipo de residuo
- 📚 Normativas legales aplicables
- 🧾 Exportación en PDF
- 🎨 Logo dinámico según la estación
- 💬 Sugerencias por SMS

## Cómo ejecutar localmente

```bash
npm install
npm run dev
```

Abre tu navegador en `http://localhost:5173`

## Despliegue

Este proyecto está listo para desplegarse directamente en [Vercel](https://vercel.com/).
