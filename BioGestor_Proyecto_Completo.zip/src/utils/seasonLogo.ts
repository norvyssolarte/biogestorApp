const winterLogo = "data:image/png;base64,...";  // Invierno
const springLogo = "data:image/png;base64,...";  // Primavera
const summerLogo = "data:image/png;base64,...";  // Verano
const autumnLogo = "data:image/png;base64,...";  // Otoño

export const getSeasonLogo = () => {
  const month = new Date().getMonth();
  if ([11, 0, 1].includes(month)) return winterLogo;
  if ([2, 3, 4].includes(month)) return springLogo;
  if ([5, 6, 7].includes(month)) return summerLogo;
  return autumnLogo;
};
